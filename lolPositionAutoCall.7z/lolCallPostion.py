import pyautogui
import os
import cv2
import numpy as np
import time
import pygetwindow as gw
import pyautogui
from pynput.keyboard import Key, Controller

print('''

===================================================================================================
     This is a little script which will automatically call league of legends position for you                                                                       
               Step 1: select which position you want to play from the list
               Step 2: start a game, leave the league of legends windows open your computer                                                                                    
               Step 3: the script will automatically search the game accept button every 5 seconds
                       once the game is found, script will press the accept button for you
                       Once you are in the game, it will automatically search the chat box and 
                       enter the position you selected for 3 times, after once second it will enter
                       the position once again
               Step 4: once the script is done, you can enter 0 to start over the script
                       (the script will start over in 5 seconds)
                       or enter any other value to exit the script.                                                                                                                                                                         
===================================================================================================
''')



loop = '0'
while loop == '0':


    
    # position dictionary 
    positionDict = {'1':'Top Please','2':'Mid Please','3':'Jungle Please','4':'Bot Please','5':'Duo Bot Please','6':'Fill'}
    # print(positionDict)
    print(positionDict)
    select = input('Select which postion you want to play from 1 - 6, then press enter: ')
    # set position
    position = positionDict[select]
    print('You have seletced ===> ',position)

    #set screenshot template image files path
    screenshotsFolderPath = os.path.dirname(os.path.abspath( __file__ ))+'/'+'Screenshots/'
    screenshotName = 'screenshot.png'
    def takeScreenShot(screenshotsFolderPath,screenshotName):
        myScreenshot = pyautogui.screenshot()
        screenshotsFolderPath = screenshotsFolderPath.replace('\\','/')
        screenshotFilePath = screenshotsFolderPath+screenshotName
        myScreenshot.save(screenshotFilePath)

    def compareImage(mainImageFilePath,templateImageFilePath,threshold):
        # Read the main image 
        img_rgb = cv2.imread(mainImageFilePath)

        # Convert it to grayscale 
        img_gray = cv2.cvtColor(img_rgb, cv2.COLOR_BGR2GRAY)

        # Read the template 
        template = cv2.imread(templateImageFilePath,0)
        # Store width and height of template in w and h 
        w, h = template.shape[::-1]

        # Perform match operations. 
        res = cv2.matchTemplate(img_gray,template,cv2.TM_CCOEFF_NORMED) 

        # Specify a threshold 
        # threshold = 0.9

        # Store the coordinates of matched area in a numpy array 
        loc = np.where( res >= threshold)  

        # Draw a rectangle around the matched region. 
        matchFound = 0
        for pt in zip(*loc[::-1]): 
            cv2.rectangle(img_rgb, pt, (pt[0] + w, pt[1] + h), (0,255,255), 2)
            matchFound += 1
        # Show the final image with the matched area. 
        # cv2.imshow('Detected',img_rgb) 

        # when the match champion found ===> store the file
        return matchFound,loc
    # while loop 
    # lolWindow = gw.getWindowsWithTitle('League of Legends')[0]
    # lolWindow.activate()
    matchFound = 0
    counter = 0
    acceptButtonFilePath = screenshotsFolderPath + 'acceptButton.jpg'
    screenshotsFolderPath = os.path.dirname(os.path.abspath( __file__ ))+'/'+'Screenshots/'
    screenshotName = 'screenshot.jpg'
    screenshotFilePath = screenshotsFolderPath + screenshotName
    while matchFound == 0:

        takeScreenShot(screenshotsFolderPath,screenshotName)
        matchFound,loc = compareImage(screenshotFilePath,acceptButtonFilePath,0.9)

        if matchFound > 0:
            x = loc[1][0]
            y = loc[0][0]
            print('found at ',x,y)
            pyautogui.click(x+100, y+30)
            chatBox = 0
            chatBoxTemplateFilePath = screenshotsFolderPath + 'championSelectLobby.jpg'
            screenshotName1 = 'chatbox.jpg'
            screenshotFilePath1 = screenshotsFolderPath + screenshotName1
            while chatBox == 0:
                
                takeScreenShot(screenshotsFolderPath,screenshotName1)
                chatBox,pos = compareImage(screenshotFilePath1,chatBoxTemplateFilePath,0.9)
                if chatBox > 0:
                    xpos = pos[1][0]
                    ypos = pos[0][0]
                    print('found at ',xpos,ypos)
                    pyautogui.click(xpos, ypos+830)
                    for a in range(0,3):
                
                        keyboard = Controller()
                        keyboard.type(position)
                        keyboard.press(Key.enter)
                        keyboard.release(Key.enter)
                        print('call position for first times')
                    # wait for 1 second and enter the postion again.    
                    time.sleep(1)
                    keyboard.type(position)
                    keyboard.press(Key.enter)
                    keyboard.release(Key.enter)
                    print('call postion for second time')
                            
                    loop = input('Enter 0 to continue, any other number to exit')
                else:
                    print('===> Searching Chat Box')
                time.sleep(1)


        else:
            print('===> Searching Accept Button ',counter)
            counter += 1
        time.sleep(5)






# chatBox = 0
# chatBoxTemplateFilePath = screenshotsFolderPath + 'championSelectLobby.jpg'
# screenshotName1 = 'chatbox.jpg'
# screenshotFilePath1 = screenshotsFolderPath + screenshotName1
# while chatBox == 0:
    
#     takeScreenShot(screenshotsFolderPath,screenshotName1)
#     chatBox,pos = compareImage(screenshotFilePath1,chatBoxTemplateFilePath,0.9)
#     if chatBox > 0:
#         xpos = pos[1][0]
#         ypos = pos[0][0]
#         print('found at ',xpos,ypos)
#         pyautogui.click(xpos, ypos+830)
#         for a in range(0,3):
    
#             keyboard = Controller()
#             keyboard.type('top')
#             keyboard.press(Key.enter)
#             keyboard.release(Key.enter)
#             print('typed')
#     else:
#         print('===> Searching Chat Box')
#     time.sleep(1)
